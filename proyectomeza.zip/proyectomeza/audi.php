<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AccesTel</title>
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="sstyle.css">
</head>
<body>

<header>
    <nav>
        <div class="logo">
            <a href="index.php">
                <img src="img/apple.png" height="50" alt="Logo de AccesTel">
            </a>
        </div>
        <nav class="navbar">
            <div class="container">
                <div class="navbar-header"></div>
                <div class="navbar-menu" id="open-navbar1">
                    <ul class="navbar-nav">
                        <li class="active"><a href="index.php">Inicio</a></li>
                        <li class="navbar-dropdown">
                            <a href="#" class="dropdown-toggler" data-dropdown="my-dropdown-id">
                                Categorías <i class="fa fa-angle-down"></i>
                            </a>
                            <ul class="dropdown" id="my-dropdown-id">
                                <li><a href="audi.php">Audífonos</a></li>
                                <li><a href="carga.php">Cargadores</a></li>
                                <li><a href="fundas.php">Fundas</a></li>
                                <li><a href="otro.php">Otros</a></li>
                            </ul>
                            <li><a href="catalogo.php">Catálogo</a></li>
                        </li>
                        <li><a href="contacto.php">Contacto</a></li>
                        <?php if (isset($_SESSION['login_user'])): ?>
                            <!-- Si el usuario está logueado, muestra el carrito y cerrar sesión -->
                            <li><a href="cart.php">
                                <img src="img/bolsa.png" alt="Carrito de compras" height="35">
                            </a></li>
                            <li><a href="logout.php">Cerrar sesión</a></li>
                        <?php else: ?>
                            <!-- Si no hay sesión activa, muestra iniciar sesión -->
                            <li><a href="iniciosesion.php">Iniciar sesión</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </nav>            
</header>
<div class="container books-container">
<?php

$host = "localhost";
$usuario = "root";
$contrasena = "";
$base_de_datos = "accesorios";

// Establecer conexión a la base de datos
$conexion = new mysqli($host, $usuario, $contrasena, $base_de_datos);

// Comprobar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Realizar la consulta para categorías diferentes a audicion, carga, y proteccion
$sentencia = "SELECT * FROM productos WHERE categoria = 'audicion'";
$resultado = $conexion->query($sentencia);

// Verificar si hay productos disponibles
if ($resultado->num_rows > 0) {
    while ($row = $resultado->fetch_assoc()) {
        echo "<div class='book'> 
                <div class='book-image-container'>
                    <img src='" . htmlspecialchars($row["imagen"]) . "' alt='" . htmlspecialchars($row["nombre"]) . "' class='book-image'>
                </div>
                <div class='book-info'>
                    <h2 class='book-title'>" . htmlspecialchars($row["nombre"]) . "</h2>
                    <p><strong>Descripción:</strong> " . htmlspecialchars($row["descripcion"]) . "</p>
                    <p><strong>Precio:</strong> $" . htmlspecialchars($row["precio"]) . "</p>
                    <form action='cart.php' method='post'>
                        <input type='hidden' name='id' value='" . htmlspecialchars($row["id"]) . "'>
                        <input type='hidden' name='name' value='" . htmlspecialchars($row["nombre"]) . "'>
                        <input type='hidden' name='price' value='" . htmlspecialchars($row["precio"]) . "'>
                        <button type='submit' class='buy-button'>Comprar</button>
                    </form>
                </div>
              </div>";
    }
} else {
    echo "<p>No hay productos disponibles.</p>";
}

// Cerrar conexión
$conexion->close();
?>
</div>

</div>
</body>
</html>