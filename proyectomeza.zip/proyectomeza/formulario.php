<?php
session_start();
include('db.php'); // Conexión a la base de datos

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $categoria = $_POST['categoria'];
    $imagen = $_POST['imagen']; // Supón que es un enlace o ruta de archivo

    // Consulta SQL para insertar el producto
    $sql = "INSERT INTO productos (Nombre, Descripcion, Precio, Categoria, Imagen, fecha_agregado)
            VALUES ('$nombre', '$descripcion', '$precio', '$categoria', '$imagen', CURDATE())";

    if ($db->query($sql)) {
        echo "Producto guardado con éxito.";
    } else {
        echo "Error en la consulta: " . $db->error;
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Producto</title>
</head>
<body>
<form method="post" action="guardarNuevoProducto.php" enctype="multipart/form-data">
    <label for="name">Nombre del Producto:</label>
    <input type="text" name="nombre" id="name" required>

    <label for="description">Descripción:</label>
    <textarea name="descripcion" id="description" required></textarea>

    <label for="price">Precio:</label>
    <input type="number" name="precio" id="price" step="0.01" required>

    <label for="categoria">Categoría:</label>
    <input type="text" name="categoria" id="categoria" required>

    <label for="imagen">Imagen:</label>
    <input type="file" name="imagen" id="imagen" accept="image/*">

    <button type="submit" class="btn btn-primary">Guardar Producto</button>
    <a href="listar.php" class="btn btn-secondary">Cancelar</a>
</form>

</body>
</html>
