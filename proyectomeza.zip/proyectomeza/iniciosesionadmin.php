<?php
session_start();
include('db.php');

if (!isset($_SESSION['admin_id'])) {
    header("Location: iniciosesion.php"); // Redirige si no es administrador
    exit();
}

// Procesar formularios
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add_product'])) {
        $nombre = $db->real_escape_string($_POST['nombre']);
        $descripcion = $db->real_escape_string($_POST['descripcion']);
        $precio = $db->real_escape_string($_POST['precio']);
        $categoria = $db->real_escape_string($_POST['categoria']);

        // Subir imagen
        if (!empty($_FILES['imagen']['name'])) {
            $imagen = $_FILES['imagen'];
            $target_dir = "uploads/";
            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0777, true);
            }
            $target_file = $target_dir . basename($imagen['name']);
            move_uploaded_file($imagen['tmp_name'], $target_file);
        } else {
            $target_file = null;
        }

        $sql = "INSERT INTO productos (nombre, descripcion, precio, categoria, imagen) 
                VALUES ('$nombre', '$descripcion', '$precio', '$categoria', '$target_file')";
        $db->query($sql);
    } elseif (isset($_POST['edit_product'])) {
        $id = $_POST['id'];
        $nombre = $db->real_escape_string($_POST['nombre']);
        $descripcion = $db->real_escape_string($_POST['descripcion']);
        $precio = $db->real_escape_string($_POST['precio']);
        $categoria = $db->real_escape_string($_POST['categoria']);

        if (!empty($_FILES['imagen']['name'])) {
            $imagen = $_FILES['imagen'];
            $target_dir = "uploads/";
            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0777, true);
            }
            $target_file = $target_dir . basename($imagen['name']);
            move_uploaded_file($imagen['tmp_name'], $target_file);
            $sql = "UPDATE productos SET nombre='$nombre', descripcion='$descripcion', precio='$precio', categoria='$categoria', imagen='$target_file' WHERE id=$id";
        } else {
            $sql = "UPDATE productos SET nombre='$nombre', descripcion='$descripcion', precio='$precio', categoria='$categoria' WHERE id=$id";
        }

        $db->query($sql);
    } elseif (isset($_POST['delete_product'])) {
        $id = $_POST['id'];
        $sql = "DELETE FROM productos WHERE id=$id";
        $db->query($sql);
    }

    // Redirige al archivo listar.php después de cualquier acción
    header("Location: listar.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Panel de Administrador</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f1e0c6; /* Beige claro */
            margin: 0;
            padding: 0;
        }

        h3 {
            text-align: center;
            color: #4e3629; /* Café oscuro */
            margin-top: 90px;
        }

        form {
            max-width: 500px;
            margin: 0 auto;
            padding: 70px;
            background-color: #fff3e0; /* Beige más cálido */
            border-radius: 10px;
            box-shadow: 0 10px 10px rgba(0, 0, 0, 0.1);
        }

        form input[type="text"], form input[type="number"], form input[type="file"], form button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #d1b79a; /* Café claro */
            border-radius: 5px;
            background-color: #fff8f0; /* Beige suave */
        }

        form button {
            background-color: #8e735b; /* Café medio */
            color: white;
            border: none;
            cursor: pointer;
        }

        form button:hover {
            background-color: #7b5e46; /* Café oscuro al pasar el mouse */
        }

        a {
            display: inline-block;
            margin: 15px 0;
            text-decoration: none;
            color: #8e735b; /* Café medio para los enlaces */
            font-weight: bold;
        }

        a:hover {
            color: #7b5e46; /* Café oscuro al pasar el mouse */
        }

        .center-links {
            text-align: center;
        }
    </style>
</head>
<body>
<h3>Agregar Producto</h3>
<form method="post" enctype="multipart/form-data">
    <input type="text" name="nombre" placeholder="Nombre" required>
    <input type="text" name="descripcion" placeholder="Descripción" required>
    <input type="number" name="precio" placeholder="Precio" required>
    <input type="text" name="categoria" placeholder="Categoría" required>
    <input type="file" name="imagen">
    <button type="submit" name="add_product">Agregar</button>
</form>

<div class="center-links">
    <a href="listar.php">Ver Productos</a>
    <br>
    <a href="cerrarsesion.php">Cerrar Sesión</a>
</div>

</body>
</html>
