<?php
// Eliminar el producto del carrito
if (isset($_GET['index'])) {
    // Leer el carrito de la cookie
    $cart = json_decode($_COOKIE['cart'], true);

    // Eliminar el producto del carrito
    if (isset($cart[$_GET['index']])) {
        unset($cart[$_GET['index']]); // Eliminar el producto usando el índice

        // Reindexar el carrito
        $cart = array_values($cart);

        // Guardar el carrito actualizado en la cookie
        setcookie('cart', json_encode($cart), time() + (86400 * 30), "/"); 

        // Redirigir al carrito de compras
        header('Location: cart_view.php');
        exit();
    }
} else {
    echo "Producto no encontrado.";
}
?>
