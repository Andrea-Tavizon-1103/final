<?php
// Datos de conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "accesorios";

// Crear la conexión
$db = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Establecer el juego de caracteres a UTF-8 (opcional)
$db->set_charset("utf8");

?>
