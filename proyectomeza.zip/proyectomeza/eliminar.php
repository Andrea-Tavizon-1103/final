<?php
if (isset($_GET['id'])) {
    $id_Producto = $_GET['id'];
    include_once 'db.php';

    $query = "DELETE FROM productos WHERE id = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("i", $id_Producto);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        header("Location: listar.php");
        exit();
    } else {
        echo "No se pudo eliminar el producto.";
    }

    $stmt->close();
} else {
    echo "No se ha proporcionado el ID del producto.";
}
?>
