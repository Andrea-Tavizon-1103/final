<?php
session_start();
include('db.php');

if (!isset($_SESSION['admin_id'])) {
    header("Location: iniciosesion.php"); // Redirige si no es administrador
    exit();
}

// Obtener productos
$sql = "SELECT * FROM productos";
$result = $db->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Productos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f1e1; /* Beige claro */
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            color: #4e3629; /* Café oscuro */
            margin-top: 20px;
        }

        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table th, table td {
            padding: 12px;
            text-align: center;
            border: 1px solid #c6a57e; /* Café claro */
        }

        table th {
            background-color: #8e735b; /* Café medio */
            color: white;
        }

        table tr:nth-child(even) {
            background-color: #eae0d2; /* Beige suave */
        }

        table img {
            max-width: 100px;
            max-height: 100px;
            object-fit: contain;
        }

        .actions form {
            display: inline-block;
            margin-right: 10px;
        }

        button {
            padding: 8px 15px;
            background-color: #8e735b; /* Café medio */
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #6f4f29; /* Café oscuro para hover */
        }

        a {
            text-decoration: none;
            color: #8e735b; /* Café medio para los enlaces */
            font-weight: bold;
        }

        a:hover {
            color: #6f4f29; /* Color más oscuro al pasar el cursor */
        }

        .form-container {
            margin: 20px auto;
            width: 80%;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .form-container input[type="text"],
        .form-container input[type="number"],
        .form-container input[type="file"],
        .form-container button {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border-radius: 5px;
            border: 1px solid #c6a57e; /* Café claro */
        }

        .form-container button {
            background-color: #8e735b; /* Café medio */
            color: white;
            cursor: pointer;
        }

        .form-container button:hover {
            background-color: #6f4f29; /* Café oscuro */
        }
    </style>
</head>
<body>
<h2>Listado de Productos</h2>

<!-- Tabla de productos -->
<table>
    <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Descripción</th>
        <th>Precio</th>
        <th>Categoría</th>
        <th>Imagen</th>
        <th>Acciones</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['nombre']; ?></td>
            <td><?php echo $row['descripcion']; ?></td>
            <td><?php echo $row['precio']; ?></td>
            <td><?php echo $row['categoria']; ?></td>
            <td>
                <?php if ($row['imagen']): ?>
                    <img src="<?php echo $row['imagen']; ?>" alt="Imagen">
                <?php else: ?>
                    Sin Imagen
                <?php endif; ?>
            </td>
            <td class="actions">
                <!-- Formulario para editar -->
                <form method="post" action="iniciosesionadmin.php" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <input type="text" name="nombre" value="<?php echo $row['nombre']; ?>" required>
                    <input type="text" name="descripcion" value="<?php echo $row['descripcion']; ?>" required>
                    <input type="number" name="precio" value="<?php echo $row['precio']; ?>" required>
                    <input type="text" name="categoria" value="<?php echo $row['categoria']; ?>" required>
                    <input type="file" name="imagen">
                    <button type="submit" name="edit_product">Editar</button>
                </form>
                <!-- Formulario para eliminar -->
                <form method="post" action="iniciosesionadmin.php">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <button type="submit" name="delete_product">Eliminar</button>
                </form>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

<!-- Enlaces -->
<div style="text-align: center;">
    <a href="iniciosesionadmin.php">Agregar Producto</a> |
    <a href="cerrarsesion.php">Cerrar Sesión</a>
</div>
</body>
</html>
