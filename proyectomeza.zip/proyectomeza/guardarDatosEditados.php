<?php
// Verifica que todos los datos requeridos estén presentes
if (
    !isset($_POST["id"]) || 
    !isset($_POST["nombre"]) || 
    !isset($_POST["descripcion"]) || 
    !isset($_POST["precio"])
) {
    echo "Todos los campos son obligatorios.";
    exit();
}

// Asignación de variables
$id = $_POST["id"];
$nombre = $_POST["nombre"];
$descripcion = $_POST["descripcion"];
$precio = $_POST["precio"];

// Conexión a la base de datos
include_once "db.php";

// Preparar la consulta SQL para actualizar el producto
$query = "UPDATE productos SET nombre = ?, descripcion = ?, precio = ? WHERE id = ?";
$stmt = $db->prepare($query);

// Vincular parámetros y ejecutar
$stmt->bind_param("ssdi", $nombre, $descripcion, $precio, $id);

if ($stmt->execute()) {
    // Redirige al listado de productos tras la actualización exitosa
    header("Location: listar.php");
    exit();
} else {
    // Muestra el error en caso de que la actualización falle
    echo "Error al actualizar el producto: (" . $stmt->errno . ") " . $stmt->error;
}

// Cerrar la consulta y conexión
$stmt->close();
$db->close();
?>
