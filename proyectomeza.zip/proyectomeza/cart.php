<?php
// Verificar si los datos del formulario están presentes
if (isset($_POST['id'], $_POST['name'], $_POST['price'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $price = floatval($_POST['price']);
    $quantity = 1; // O la cantidad que venga del formulario

    // Leer el carrito existente de la cookie
    $cart = [];
    if (isset($_COOKIE['cart'])) {
        $cart = json_decode($_COOKIE['cart'], true); // Decodificar el carrito de la cookie
    }

    // Verificar si el producto ya está en el carrito
    $exists = false;
    foreach ($cart as &$item) {
        if ($item['id'] == $id) {
            $item['quantity'] += $quantity; // Si ya está, aumentar la cantidad
            $exists = true;
            break;
        }
    }

    // Si el producto no existe, agregarlo al carrito
    if (!$exists) {
        $cart[] = [
            'id' => $id,
            'name' => $name,
            'price' => $price,
            'quantity' => $quantity
        ];
    }

    // Guardar el carrito actualizado en la cookie (expira en 30 días)
    setcookie('cart', json_encode($cart), time() + (86400 * 30), "/"); 

    // Redirigir al carrito después de agregar
    header('Location: cart_view.php');
    exit();
}
?>
