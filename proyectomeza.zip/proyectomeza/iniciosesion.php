<?php
session_start();
include('db.php'); // Conexión a la base de datos

// Verificar si el formulario de usuario ha sido enviado
if (isset($_POST['user_login'])) {

    // Recoger los datos del formulario
    $username = $_POST['usuario'];
    $password = $_POST['contrasena'];

    // Prevenir SQL Injection
    $username = $db->real_escape_string($username);
    $password = $db->real_escape_string($password);

    // Consulta para verificar si el usuario existe
    $sql = "SELECT id, usuario, contrasena FROM usuarios WHERE usuario='$username'";

    // Ejecutar la consulta
    $result = $db->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Verificar la contraseña
        if ($password === $row['contrasena']) {
            $_SESSION['login_user'] = $row['usuario']; // Guardar el usuario en la sesión
        
            // Redirigir al sitio principal
            header("Location: index.php");
            exit();
        } else {
            $error_message = "Contraseña inválida.";
        }
    } else {
        $error_message = "Usuario no encontrado.";
    }
}

// Verificar si el formulario de administrador ha sido enviado
if (isset($_POST['admin_login'])) {
    // Recoger los datos del formulario de administrador
    $admin_username = $_POST['admin_usuario'];
    $admin_password = $_POST['admin_contrasena'];

    // Prevenir SQL Injection
    $admin_username = $db->real_escape_string($admin_username);
    $admin_password = $db->real_escape_string($admin_password);

    // Consulta para verificar si el administrador existe
    $query = "SELECT * FROM admins WHERE usuario = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("s", $admin_username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $admin = $result->fetch_assoc();
        if ($admin_password === $admin['contrasena']) { // Si las contraseñas coinciden (en texto plano)
            // Iniciar sesión como administrador y redirigir al panel
            $_SESSION['admin_id'] = $admin['id'];
            header("Location: iniciosesionadmin.php");
            exit;
        } else {
            // Contraseña incorrecta para el administrador
            echo "<script>alert('Contraseña incorrecta.'); window.location.href='iniciosesionadmin.php';</script>";
        }
    } else {
        // Administrador no encontrado
        echo "<script>alert('Administrador no encontrado.'); window.location.href='iniciosesionadmin.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilos/1.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>accestel</title>
    <style>
        @import url(https://fonts.googleapis.com/css?family=Poppins:300);

        body {
            height: 100vh;
            overflow: hidden;
            font-family: "Poppins";
            background: #46341a;
        }
        .login-page {
            width: 400px;
            padding: 8% 0 0;
            margin: auto;
        }
        .form {
            position: relative;
            z-index: 1;
            background: #FFFFFF;
            max-width: 400px;
            margin: 0 auto 100px;
            padding: 45px;
            text-align: center;
            border-radius: 15px;
            box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
        }
        .form input {
            font-family: "Poppins", sans-serif;
            outline: 0;
            background: #f2f2f2;
            width: 100%;
            border: 0;
            border-radius: 7px;
            margin: 0 0 15px;
            padding: 15px;
            box-sizing: border-box;
            font-size: 14px;
        }
        .form button {
            font-family: "Poppins", sans-serif;
            text-transform: uppercase;
            outline: 0;
            background: #ac8738;
            width: 100%;
            border: 0;
            padding: 15px;
            color: #FFFFFF;
            border-radius: 7px;
            font-size: 14px;
            -webkit-transition: all 0.3 ease;
            transition: all 0.3 ease;
            cursor: pointer;
        }
        .form button:hover,.form button:active,.form button:focus {
            background: #b39d3b;
        }
        .form .message {
            margin: 15px 0 0;
            color: #b3b3b3;
            font-size: 12px;
        }
        .form .message a {
            color: #664f23;
            text-decoration: none;
        }
        .form .register-form {
            display: none;
        }
    </style>
</head>
<body>
    <div class="login-page">
        <div class="form">
            <h2 class="mb-4"><img src="img/usuario.png" width="100" alt=""></h2>
            <!-- Formulario de Login de Usuario -->
            <form method="POST">
                <div class="mb-3">
                    <label for="usuario" class="form-label">Correo Electrónico o Usuario</label>
                    <input type="text" class="form-control" id="usuario" name="usuario" required>
                </div>
                <div class="mb-3">
                    <label for="contrasena" class="form-label">Contraseña</label>
                    <input type="password" class="form-control" id="contrasena" name="contrasena" required>
                </div>
                <button type="submit" name="user_login" class="btn btn-success w-100">Iniciar Sesión</button>
                <p class="message">¿No tienes cuenta? <a href="Registrarse.php">Regístrate</a></p>
            </form>

            <!-- Botón para abrir el modal de inicio de sesión como administrador -->
            <button type="button" class="btn btn-warning w-100 mt-3" data-bs-toggle="modal" data-bs-target="#adminModal">
                Iniciar Sesión como Administrador
            </button>
        </div>
    </div>

    <!-- Modal de inicio de sesión para Admin -->
    <div class="modal fade" id="adminModal" tabindex="-1" aria-labelledby="adminModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="adminModalLabel">Iniciar Sesión como Administrador</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label for="admin_usuario" class="form-label">Usuario</label>
                            <input type="text" class="form-control" id="admin_usuario" name="admin_usuario" required>
                        </div>
                        <div class="mb-3">
                            <label for="admin_contrasena" class="form-label">Contraseña</label>
                            <input type="password" class="form-control" id="admin_contrasena" name="admin_contrasena" required>
                        </div>
                        <button type="submit" name="admin_login" class="btn btn-danger w-100">Iniciar Sesión como Admin</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
