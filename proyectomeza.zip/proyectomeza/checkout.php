<?php
// Habilitar la visualización de errores para depuración
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Obtener la fecha actual
$fecha = date("d/m/Y");

// Validar que el carrito existe y tiene productos en la cookie
if (!isset($_COOKIE['cart']) || empty($_COOKIE['cart'])) {
    echo "
    <div class='empty-cart'>
        <h2>No hay productos en el carrito.</h2>
        <a href='catalogo.php' class='button'>Regresar al catálogo</a>
    </div>";
    exit(); // Terminar la ejecución si el carrito está vacío
}

// Decodificar el carrito guardado en la cookie
$cart = json_decode($_COOKIE['cart'], true);

// Inicializar variables para el subtotal y el total
$subTotal = 0;

// Crear el encabezado del ticket
$ticket = "
<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Ticket de Compra</title>
    <link rel='stylesheet' type='text/css' href='styleTt.css'>
    <link rel='stylesheet' type='text/css' href='styleCH.css'>
</head>
<body>
    <div class='ticket-container'>
        <div class='abc'>
            <img src='img/apple.png' alt='Logo'>
            <h2>AccesTel</h2>
        </div>
        <div class='eslogan'>
            <h4>'Tu vida en un lugar'</h4>
        <h1>Ticket de Compra</h1>
        <p>Fecha: $fecha</p>
        </div>
        <table>
            <tr>
                <th>Producto</th>
                <th>Precio Unitario</th>
                <th>Cantidad</th>
                <th>Total</th>
            </tr>";

// Iterar sobre los productos del carrito
foreach ($cart as $item) {
    if (!isset($item['name'], $item['price'], $item['quantity'])) {
        continue;
    }

    $totalProducto = $item['price'] * $item['quantity'];
    $subTotal += $totalProducto;

    $ticket .= "
            <tr>
                <td>" . htmlspecialchars($item['name']) . "</td>
                <td>$" . number_format($item['price'], 2) . "</td>
                <td>" . htmlspecialchars($item['quantity']) . "</td>
                <td>$" . number_format($totalProducto, 2) . "</td>
            </tr>";
}

$iva = $subTotal * 0.16;
$totalConIva = $subTotal + $iva;

$ticket .= "
            <tr>
                <td colspan='3'><strong>Subtotal</strong></td>
                <td>$" . number_format($subTotal, 2) . "</td>
            </tr>
            <tr>
                <td colspan='3'><strong>IVA (16%)</strong></td>
                <td>$" . number_format($iva, 2) . "</td>
            </tr>
            <tr>
                <td colspan='3'><strong>Total</strong></td>
                <td>$" . number_format($totalConIva, 2) . "</td>
            </tr>
        </table>
    </div>

    <!-- Botón para regresar al index -->
    <div class='back-button'>
        <a href='index.php'>
            <button class='button'>Regresar al inicio</button>
        </a>
    </div>

    <footer>
        <p>'Tu vida en un lugar'<br> Andrea Tavizon Torres <br> 22308051281103</p>
    </footer>
</body>
</html>";

echo $ticket;
?>
