<?php
// Manejo de la eliminación de productos del carrito
if (isset($_GET['index'])) {
    $index = $_GET['index'];

    // Verificar si la cookie 'cart' existe
    if (isset($_COOKIE['cart'])) {
        // Obtener el carrito desde la cookie
        $cart = json_decode($_COOKIE['cart'], true);

        // Verificar si el índice del producto existe en el carrito
        if (isset($cart[$index])) {
            // Eliminar el producto
            unset($cart[$index]);
            // Reindexar el array
            $cart = array_values($cart);

            // Guardar el carrito actualizado en la cookie
            setcookie('cart', json_encode($cart), time() + (86400 * 30), "/"); // Válido por 30 días
        }
    }
    // Redirigir a la página del carrito para actualizar la vista
    header("Location: cart_view.php");
    exit();
}

// Manejo de vaciado del carrito
if (isset($_POST['vaciar_carrito'])) {
    // Eliminar la cookie del carrito
    setcookie('cart', '', time() - 3600, '/'); // Eliminar la cookie
    header("Location: cart_view.php"); // Redirigir a la página de carrito vaciado
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Carrito de Compras</title>
    <link rel="stylesheet" href="stylesS.css">
    <link rel="stylesheet" href="styleCar.css">
</head>
<body>

    <!-- ENCABEZADO --> 
    <header>
        <div class="container">
            <img class="imag" src="images/x/logo.png" alt="">
        </div>
        <hr size="2" width="99.9%" color="000">
    </header>

    <!-- CARRITO -->
    <div class="contenedor">
        <h1>Bolsa</h1>

        <?php
        // Verificar si la cookie 'cart' existe y mostrar los productos del carrito
        if (isset($_COOKIE['cart'])) {
            $cart = json_decode($_COOKIE['cart'], true);
            if (count($cart) > 0) {
                $subtotal = 0;
                // Mostrar cada producto en el carrito
                foreach ($cart as $key => $item) {
                    $name = isset($item['name']) ? $item['name'] : 'Sin nombre';
                    $price = isset($item['price']) ? $item['price'] : 0;
                    $quantity = isset($item['quantity']) ? $item['quantity'] : 0;

                    // Calcular subtotal
                    $subtotal += $price * $quantity;

                    // Mostrar cada producto en el carrito
                    echo "<div class='cart-item'>
                            <span><strong>Producto:</strong> $name (x$quantity)</span>
                            <span><strong>Precio:</strong> \$$price</span>
                            <button class='delete-btn' onclick='removeFromCart($key)'>Eliminar</button>
                          </div>";
                }
                echo "<h2>Subtotal: \$$subtotal</h2>";
            } else {
                echo "<h3>Tu carrito está vacío.</h3>";
            }
        } else {
            echo "<h3>Tu carrito está vacío.</h3>";
        }
        ?>

        <!-- BOTONES -->
        <a href="checkout.php" class="button-cart">Finalizar compra</a>
        <a href="catalogo.php" class="button-cart">Continuar comprando</a>
        <form action="" method="post">
            <button type="submit" name="vaciar_carrito" class="button-cart">Vaciar Carrito</button>
        </form>
    </div>

    <!-- VENTANA PARA ELIMINAR PRODUCTO -->
    <script>
        function removeFromCart(index) {
            if (confirm("¿Estás seguro de eliminar este producto del carrito?")) {
                // Redirigir a la misma página con el índice del producto a eliminar
                window.location.href = "cart_view.php?index=" + index;
            }
        }
    </script>
    
</body>

</html>
